int *p=NULL;
...
if (p) {  // p!=NULL
  <Mit p oder *p arbeiten>
} else {  // p==NULL
  <p zuweisen>
}
