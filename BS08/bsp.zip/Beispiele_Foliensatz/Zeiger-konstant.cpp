class K {};
K k;
K* const pK = &k; // pk wird unwideruflich
                  // an das Objekt k gebunden
//! Beachte: Das Schluesselwort const steht
//! hinter K*

