/* vollstaendige Initialisierung */
int tage[6]={31,28,31,30,27,31}; 

/* unvollstaendige Initialisierung */
int n[5]={1,2,3};  /* n[3]=0, n[4]=0 */

/* Dimension durch Initialisierung festgelegt */
int tage[]={31,28,31,30,27,31};

