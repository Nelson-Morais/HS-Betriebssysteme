void *zeiger;
double d;
long int l;
zeiger=&d;  // geht
zeiger=&l;  // geht auch
