char text[8] = {'S','t','r','i','n','g','!','\0'};
char text[] = "String!";  //Dasselbe wie
// char* text= "String!"; //dieses hier
//! Beachte: text besteht wegen des abschließenden
//! '\0' aus 8 Zeichen
 
// "Hallo"[1] ist das Zeichen 'a'
// "Hallo"[5] ist das Element '\0'
